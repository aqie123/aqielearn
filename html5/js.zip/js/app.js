(function(document){   //document通过参数获得，避免作用域链一层层搜索
	var gameInst;
	function DomObject(dom){
		this.dom =dom;
	}
	DomObject.prototype.get = function(){
		return this.dom;
	}

	DomObject.prototype.on = function(eventName,eventHandler){  //事件注册
		this.get().addEventListener(eventName,eventHandler);
	}

	DomObject.prototype.css = function(styleKey,styleValue){
		this.get().style[styleKey] = styleValue;
	}

	function $(selector,context){    //context在哪里去找，如果没有就用document
		return new DomObject((context || document).querySelector(selector));
	}

	//创建方法，启动游戏
	function startGame(){
		ResourceManager.onResourceLoaded = function(){
			// new Board();   测试显示第一个图形
			new Tetris().startGame();    //启动游戏	
		}			
		ResourceManager.init();      //调用init方法
	}
	function _init(){   //初始化
		$('.btn-success').on('click',function(ev){
			$('.start-container').css('display','none');
			$('.game-container').css('display','block');
			startGame();
		});
		$('.btn-info').on('click',function(){
			// alert("睡觉")
			window.location.href="http://www.maiziedu.com/course/878-12940/";
		})
	}

	document.addEventListener('DOMContentLoaded',function(ev){
		_init();
	})
})(document);