(function(window){
	'use strict';

	// var intervalId;  //计时器id
	// var speed = 400;


	function Tetris(){      //游戏对象
		this.board = new Board();
		(new Keyboard()).init(this.board);    //初始化键盘事件，启动keyboard
	};

	Tetris.prototype={
		constructor:Tetris,
		_startTick(){			
			
		},
		_stopTick:function(){      

		},
		startGame:function(){		//开始游戏
			var self = this;
			window.TetrisConfig.intervalId = window.setInterval(function(){
				self.board.tick();   //每次跳动  this和tetris的this不一样，用self变量调用
			},TetrisConfig.speed);
		},
		endGame:function(){			//结束游戏

		}
	}
	window.Tetris = Tetris;
})(window);