(function(window){
	window.TetrisConfig = {
		rows:20,
		cols:13,
		speed:1000,
		constSpeed:1000,
		intervalId:0,
		config:{}
	};

})(window);